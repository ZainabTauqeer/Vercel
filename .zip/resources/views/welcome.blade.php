<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="VaultEdge - Premium financial planning and investment management HTML template">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>VaultEdge - Financial Planning &amp; Investment HTML Template</title>
<link rel="stylesheet" href="{{ asset('css/style.css') }}">

<link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset('css/animate.css') }}">
<link rel="stylesheet" href="{{ asset('css/font-awesome.min.css') }}">
<link rel="stylesheet" href="{{ asset('css/custom-override.css') }}">
</head>

<body>
    <!-- Preloader -->
    <div class="preloader d-flex align-items-center justify-content-center">
        <div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>
    </div>

    <!-- ===== NAVBAR (single dark bar, logo left, nav center, CTA right) ===== -->
    <header class="ve-header" id="ve-sticky">
        <div class="container-fluid ve-nav-wrap">
            <!-- Logo -->
            <div class="ve-logo">
                <a href="{{ url('/') }}">
                    <span class="ve-logo-icon">V</span>
                    <span class="ve-logo-text">Vault<strong>Edge</strong></span>
                </a>
            </div>

            <!-- Nav Links -->
            <!-- <nav class="ve-nav">
                <ul>
                    <li><a href="{{ url('/') }}" class="active">Home</a></li>
                    <li class="has-drop">
                        <a href="{{ url('/about') }}">About <i class="fa fa-angle-down"></i></a>
                        <ul class="ve-dropdown">
                            <li><a href="{{ url('/about') }}">About Us</a></li>
                            <li><a href="{{ url('/services') }}">Our Services</a></li>
                            <li><a href="{{ url('/elements') }}">UI Elements</a></li>
                        </ul>
                    </li>
                    <li><a href="{{ url('/services') }}">Services</a></li>
                    <li class="has-drop">
                        <a href="#">Solutions <i class="fa fa-angle-down"></i></a>
                        <ul class="ve-dropdown">
                            <li><a href="#">Wealth Management</a></li>
                            <li><a href="#">Retirement Plans</a></li>
                            <li><a href="#">Tax Advisory</a></li>
                            <li><a href="#">Risk Analysis</a></li>
                        </ul>
                    </li>
                    <li><a href="{{ url('/insights') }}">Insights</a></li>
                    <li><a href="{{ url('/contact') }}">Contact</a></li>
                </ul>
            </nav> -->

            <!-- CTA -->
            <div class="ve-nav-cta">
                <a href="{{ url('/contact') }}" class="ve-cta-btn">Get Started <i class="fa fa-arrow-right"></i></a>
            </div>

            <!-- Mobile Toggle -->
            <button class="ve-toggler" id="ve-toggle">
                <span></span><span></span><span></span>
            </button>
        </div>

        <!-- Mobile Menu -->
        <div class="ve-mobile-menu" id="ve-mobile-menu">
            <ul>
                <li><a href="{{ url('/') }}">Home</a></li>
                <li><a href="{{ url('/about') }}">About</a></li>
                <li><a href="{{ url('/services') }}">Services</a></li>
                <li><a href="#">Solutions</a></li>
                <li><a href="{{ url('/insights') }}">Insights</a></li>
                <li><a href="{{ url('/contact') }}">Contact</a></li>
            </ul>
        </div>
    </header>
    <section class="ve-hero">
    <div class="ve-hero-left">
        <span class="ve-hero-badge">Become Job-Ready. Build Real Skills. Launch Your Career.</span>
        <h1>Accounting Industry <br><span class="ve-highlight">Readiness</span> Programme</h1>
        <p>The Accounting Industry Readiness Programme is designed to bridge the gap between academic qualifications and real-world employment. This programme equips aspiring accountants with practical experience, digital expertise, and workplace readiness, transforming students into confident, job-ready professionals.</p>
        <p>Whether you’re currently studying or planning a career in accounting, this is your pathway to success in the modern finance industry.</p>
        
        <div class="ve-hero-btns">
            <a href="{{ url('/services') }}" class="ve-btn-primary">Explore Services</a>
            <a href="{{ url('/about') }}" class="ve-btn-ghost">Learn More</a>
        </div>

        <div class="ve-hero-stats">
            <div class="ve-stat">
                <strong>Practical</strong>
                <span>Experience</span>
            </div>
            <div class="ve-stat-divider"></div>
            <div class="ve-stat">
                <strong>Digital</strong>
                <span>Expertise</span>
            </div>
            <div class="ve-stat-divider"></div>
            <div class="ve-stat">
                <strong>Job</strong>
                <span>Ready</span>
            </div>
        </div>
    </div>

    <div class="ve-hero-right">
        <div class="ve-hero-img-main bg-img" style="background-image:url({{ asset('img/bg-img/1.jpg') }});"></div>
        <div class="ve-hero-img-accent bg-img" style="background-image:url({{ asset('img/bg-img/3.jpg') }});"></div>
        
        <div class="ve-float-card">
            <i class="fa fa-graduation-cap"></i>
            <div>
                <strong>Pathway</strong>
                <span>To Success</span>
            </div>
        </div>
    </div>
</section>



    <!-- ===== MARQUEE TRUST BAR ===== -->
    <div class="ve-trust-bar">
        <div class="ve-trust-inner">
            <span><i class="fa fa-shield"></i> Bank-Grade Security</span>
            <span><i class="fa fa-check-circle"></i> SEC Registered</span>
            <span><i class="fa fa-users"></i> 50,000+ Clients Worldwide</span>
            <span><i class="fa fa-lock"></i> 256-bit Encryption</span>
            <span><i class="fa fa-trophy"></i> Award Winning Advisory</span>
            <span><i class="fa fa-globe"></i> 30+ Countries Served</span>
            <span><i class="fa fa-shield"></i> Bank-Grade Security</span>
            <span><i class="fa fa-check-circle"></i> SEC Registered</span>
            <span><i class="fa fa-users"></i> 50,000+ Clients Worldwide</span>
            <span><i class="fa fa-lock"></i> 256-bit Encryption</span>
        </div>
    </div>

<section class="ve-section ve-whyus-section">
    <div class="container">
        <div class="row align-items-center">
            <!-- Image Side -->
            <div class="col-12 col-lg-5">
                <div class="ve-whyus-img-wrap wow fadeInLeft" data-wow-delay="100ms">
                    <div class="ve-whyus-img-main bg-img" style="background-image:url({{ asset('img/bg-img/5.jpg') }});"></div>
                    <div class="ve-whyus-badge">
                        <strong>Ready</strong>
                        <span>For the Job Market</span>
                    </div>
                </div>
            </div>
            <!-- Content Side -->
            <div class="col-12 col-lg-7 wow fadeInRight" data-wow-delay="200ms">
                <div class="ve-whyus-content">
                    <span class="ve-section-tag">Value Proposition</span>
                    <h2>Why Choose This <span>Programme?</span></h2>
                    <p>In today’s competitive job market, qualifications alone are not enough. Employers are looking for candidates who can:</p>
                    
                    <div class="ve-checklist">
                        <div class="ve-check-item">
                            <i class="fa fa-check-circle"></i>
                            <div><strong>Real-World Application</strong><p>Apply knowledge in real business scenarios</p></div>
                        </div>
                        <div class="ve-check-item">
                            <i class="fa fa-check-circle"></i>
                            <div><strong>Technical Proficiency</strong><p>Use accounting software confidently</p></div>
                        </div>
                        <div class="ve-check-item">
                            <i class="fa fa-check-circle"></i>
                            <div><strong>Data Mastery</strong><p>Analyse data and provide insights</p></div>
                        </div>
                        <div class="ve-check-item">
                            <i class="fa fa-check-circle"></i>
                            <div><strong>Future-Ready Finance</strong><p>Understand automation and AI in finance</p></div>
                        </div>
                        <div class="ve-check-item">
                            <i class="fa fa-check-circle"></i>
                            <div><strong>Soft Skills</strong><p>Communicate professionally in the workplace</p></div>
                        </div>
                    </div>
                    
                    <p class="mt-30"><strong>This programme is built to help you develop exactly those in-demand skills.</strong></p>
                    <a href="{{ url('/about') }}" class="ve-btn-primary mt-10">Discover Our Story</a>
                </div>
            </div>
        </div>
    </div>
</section>

 <section class="ve-section ve-services-section">
    <div class="container">
        <div class="ve-section-header text-center">
            <h2 class="ve-section-tag">Your Roadmap to Success</h2>
        </div>
        <div class="ve-services-grid">
            <div class="ve-service-card wow fadeInUp" data-wow-delay="100ms">
                <div class="ve-service-icon"><i class="fa fa-calculator"></i></div>
                <h4>1. Practical Accounting Experience</h4>
                <p>Gain hands-on experience in a chartered accounting firm environment, working on:</p>
                <ul style="list-style: disc; text-align: left; padding-left: 20px; font-size: 14px; color: #666;">
                    <li>Bookkeeping for limited companies</li>
                    <li>VAT returns and HMRC submissions</li>
                    <li>Statutory financial statements</li>
                    <li>Companies House submissions</li>
                    <li>Real-world use of Sage, QuickBooks, and Xero</li>
                </ul>
            </div>

            <div class="ve-service-card wow fadeInUp" data-wow-delay="200ms">
                <div class="ve-service-icon"><i class="fa fa-line-chart"></i></div>
                <h4>2. Data Analytics for Finance</h4>
                <p>Develop powerful analytical skills to support decision-making:</p>
                <ul style="list-style: disc; text-align: left; padding-left: 20px; font-size: 14px; color: #666;">
                    <li>Excel Lookups & Pivot Tables</li>
                    <li>Advanced dashboards and reporting</li>
                    <li>Financial data interpretation</li>
                    <li>Introduction to Power BI</li>
                </ul>
            </div>

            <div class="ve-service-card wow fadeInUp" data-wow-delay="300ms">
                <div class="ve-service-icon"><i class="fa fa-microchip"></i></div>
                <h4>3. AI in Accounting</h4>
                <p>Prepare for the future of finance by understanding how AI is transforming the industry:</p>
                <ul style="list-style: disc; text-align: left; padding-left: 20px; font-size: 14px; color: #666;">
                    <li>Automation of routine accounting tasks</li>
                    <li>Data processing and extraction</li>
                    <li>Generating financial insights</li>
                    <li>Understanding risks and ethical considerations</li>
                </ul>
            </div>

            <div class="ve-service-card wow fadeInUp" data-wow-delay="400ms">
                <div class="ve-service-icon"><i class="fa fa-laptop"></i></div>
                <h4>4. Digital Finance & Automation</h4>
                <p>Learn how modern finance teams operate efficiently:</p>
                <ul style="list-style: disc; text-align: left; padding-left: 20px; font-size: 14px; color: #666;">
                    <li>Workflow automation</li>
                    <li>Bank feeds and cloud accounting</li>
                    <li>Process optimisation (invoicing, reconciliations, reporting)</li>
                    <li>Introduction to RPA (Robotic Process Automation)</li>
                </ul>
            </div>

            <div class="ve-service-card wow fadeInUp" data-wow-delay="500ms">
                <div class="ve-service-icon"><i class="fa fa-briefcase"></i></div>
                <h4>5. Employability & Career Development</h4>
                <p>Stand out to employers with professional skills and confidence:</p>
                <ul style="list-style: disc; text-align: left; padding-left: 20px; font-size: 14px; color: #666;">
                    <li>CV writing and LinkedIn optimisation</li>
                    <li>Interview preparation and mock interviews</li>
                    <li>Professional communication skills</li>
                    <li>Real-world “day in the life” simulations</li>
                </ul>
            </div>
        </div>
    </div>
</section>

 <!-- ===== CTA BANNER ===== -->
    <section class="ve-cta-banner bg-img" style="background-image:url({{ asset('img/bg-img/6.jpg') }});">
        <div class="ve-cta-overlay"></div>
        <div class="container ve-cta-content">
            <div class="row align-items-center">
                <div class="col-12 col-lg-8">
                    <h2>Designed for <span>Future Finance Professionals</span></h2>
                    <p>This programme aligns with the evolving needs of the accounting profession, focusing on developing modern, digitally proficient finance professionals who are ready to thrive in today’s workplace.</p>
                </div>
                <div class="col-12 col-lg-4 text-lg-right">
                    <a href="{{ url('/contact') }}" class="ve-btn-white">Join Now</a>
                </div>
            </div>
        </div>
    </section>

    <section class="ve-section ve-testimonials-section">
    <div class="container">
        <div class="ve-section-header text-center">
            <span class="ve-section-tag">Benefits</span>
            <h2>Programme <span>Outcome</span></h2>
            <p>By the end of the programme, you will:</p>
        </div>
        <div class="ve-testi-grid">
            <div class="ve-testi-card wow fadeInUp" data-wow-delay="100ms">
                <div class="ve-testi-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
                <p>Apply your accounting knowledge in real-world scenarios</p>
            </div>
            
            <div class="ve-testi-card wow fadeInUp" data-wow-delay="200ms">
                <div class="ve-testi-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
                <p>Gain practical experience alongside your studies</p>
            </div>

            <div class="ve-testi-card wow fadeInUp" data-wow-delay="300ms">
                <div class="ve-testi-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
                <p>Develop digital, analytical, and AI-driven skills</p>
            </div>

            <div class="ve-testi-card wow fadeInUp" data-wow-delay="400ms">
                <div class="ve-testi-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
                <p>Build confidence using industry-standard software</p>
            </div>

            <div class="ve-testi-card wow fadeInUp" data-wow-delay="500ms">
                <div class="ve-testi-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
                <p>Significantly improve your job prospects</p>
            </div>

            <div class="ve-testi-card wow fadeInUp" data-wow-delay="600ms">
                <div class="ve-testi-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
                <p>Become job-ready before completing your qualification</p>
            </div>
        </div>
    </div>
</section>
   
    <!-- ===== LATEST INSIGHTS ===== -->
    <!-- <section class="ve-section ve-insights-section">
        <div class="container">
            <div class="ve-section-header text-center">
                <span class="ve-section-tag">Blog &amp; News</span>
                <h2>Latest Financial <span>Insights</span></h2>
                <p>Stay ahead with expert commentary, market analysis, and actionable financial tips.</p>
            </div>
            <div class="row">
                <div class="col-12 col-md-4 wow fadeInUp" data-wow-delay="100ms">
                    <div class="ve-insight-card">
                        <div class="ve-insight-img bg-img" style="background-image:url({{ asset('img/bg-img/10.jpg') }});"></div>
                        <div class="ve-insight-body">
                            <span class="ve-insight-cat">Investment</span>
                            <h5><a href="{{ url('/single-post') }}">5 Smart Investment Strategies for 2025</a></h5>
                            <p>Discover the top strategies seasoned investors are using to grow wealth in volatile markets.</p>
                            <div class="ve-insight-meta">
                                <span><i class="fa fa-calendar"></i> April 26</span>
                                <a href="{{ url('/single-post') }}">Read More <i class="fa fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 wow fadeInUp" data-wow-delay="250ms">
                    <div class="ve-insight-card">
                        <div class="ve-insight-img bg-img" style="background-image:url({{ asset('img/bg-img/11.jpg') }});"></div>
                        <div class="ve-insight-body">
                            <span class="ve-insight-cat">Credit</span>
                            <h5><a href="{{ url('/single-post') }}">Understanding Your Credit Score in 2025</a></h5>
                            <p>Learn the key factors that influence your credit score and how to improve it fast.</p>
                            <div class="ve-insight-meta">
                                <span><i class="fa fa-calendar"></i> April 20</span>
                                <a href="{{ url('/single-post') }}">Read More <i class="fa fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 wow fadeInUp" data-wow-delay="400ms">
                    <div class="ve-insight-card">
                        <div class="ve-insight-img bg-img" style="background-image:url({{ asset('img/bg-img/12.jpg') }});"></div>
                        <div class="ve-insight-body">
                            <span class="ve-insight-cat">Savings</span>
                            <h5><a href="{{ url('/single-post') }}">Building Wealth in Your 30s — A Full Guide</a></h5>
                            <p>The financial habits and investment moves that set you up for lifelong prosperity.</p>
                            <div class="ve-insight-meta">
                                <span><i class="fa fa-calendar"></i> April 14</span>
                                <a href="{{ url('/single-post') }}">Read More <i class="fa fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->

    <!-- ===== NEWSLETTER ===== -->
   <section class="ve-newsletter-section">
        <div class="container">
            <div class="ve-newsletter-wrap">
                <div class="ve-nl-left">
                    <i class="fa fa-envelope-o"></i>
                    <div>
                        <h3>Start Your Journey Today</h3>
                        <p>Take the next step towards your accounting career with a programme that goes beyond theory and prepares you for real success. Enquire now and become a job-ready accounting professional.</p>
                    </div>
                </div>
                <!-- <div class="ve-nl-right">
                    <form class="ve-nl-form" action="#" method="post">
                        @csrf
                        <input type="email" name="email" placeholder="Enter your email address" required>
                        <button type="submit">Enquire Now</button>
                    </form>
                </div>
            </div> -->
        </div>
    </section>

    <!-- ===== FOOTER (dark, 4-column) ===== -->
    <footer class="ve-footer">
        <div class="container">
            <div class="row">
                <!-- Col 1: Brand -->
                <div class="col-12 col-sm-6 col-lg-4 mb-50">
                    <div class="ve-footer-brand">
                        <a href="{{ url('/') }}" class="ve-footer-logo">
                            <span class="ve-logo-icon">V</span>
                            <span class="ve-logo-text">Vault<strong>Edge</strong></span>
                        </a>
                        <p>Empowering individuals and businesses with intelligent financial strategies since 2012.</p>
                        <div class="ve-social">
                            <a href="#"><i class="fa fa-facebook"></i></a>
                            <a href="#"><i class="fa fa-twitter"></i></a>
                            <a href="#"><i class="fa fa-linkedin"></i></a>
                            <a href="#"><i class="fa fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
                <!-- Col 2: Quick Links -->
                <div class="col-12 col-sm-6 col-lg-2 mb-50">
                    <h5 class="ve-footer-title">Quick Links</h5>
                    <ul class="ve-footer-links">
                        <li><a href="{{ url('/') }}">Home</a></li>
                        <li><a href="{{ url('/about') }}">About Us</a></li>
                        <li><a href="{{ url('/services') }}">Services</a></li>
                        <li><a href="{{ url('/insights') }}">Insights</a></li>
                        <li><a href="{{ url('/contact') }}">Contact</a></li>
                    </ul>
                </div>
                <!-- Col 3: Services -->
                <div class="col-12 col-sm-6 col-lg-3 mb-50">
                    <h5 class="ve-footer-title">Our Services</h5>
                    <ul class="ve-footer-links">
                        <li><a href="#">Investment Planning</a></li>
                        <li><a href="#">Wealth Management</a></li>
                        <li><a href="#">Retirement Plans</a></li>
                        <li><a href="#">Tax Advisory</a></li>
                        <li><a href="#">Risk Management</a></li>
                    </ul>
                </div>
                <!-- Col 4: Contact -->
                <div class="col-12 col-sm-6 col-lg-3 mb-50">
                    <h5 class="ve-footer-title">Get In Touch</h5>
                    <ul class="ve-footer-contact">
                        <li><i class="fa fa-map-marker"></i> 42 Harbor View, San Francisco, CA</li>
                        <li><i class="fa fa-phone"></i> +1 800 555 0199</li>
                        <li><i class="fa fa-envelope"></i> hello@vaultedge.com</li>
                        <li><i class="fa fa-clock-o"></i> Mon–Fri, 9am – 6pm</li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Footer Bottom Bar -->
        <div class="ve-footer-bottom">
            <div class="container">
                <div class="ve-footer-bottom-inner">
                    <p>Copyright &copy; {{ date('Y') }} VaultEdge. All Rights Reserved <a href="https://github.com/Rabina-Vishwakarma/" class="text-white" target="_blank">Rabina Vishwakarma</a> • Distributed by <a href="https://themewagon.com" class="text-white" target="_blank">ThemeWagon</a></p>
                    <ul>
                        <li><a href="#">Privacy Policy</a></li>
                        <li><a href="#">Terms of Use</a></li>
                        <li><a href="#">Cookie Policy</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="{{ asset('js/jquery/jquery-2.2.4.min.js') }}"></script>
    <script src="{{ asset('js/bootstrap/popper.min.js') }}"></script>
    <script src="{{ asset('js/bootstrap/bootstrap.min.js') }}"></script>
    <script src="{{ asset('js/plugins/plugins.js') }}"></script>
    <script src="{{ asset('js/active.js') }}"></script>
    <script src="{{ asset('js/vaultedge.js') }}"></script>
</body>
</html>